letters = 'ABCDEFGHIJKLMNOPQRST';
for i=1:20
    run("model_"+letters(i)+".m")
end

