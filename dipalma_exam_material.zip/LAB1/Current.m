classdef Current
    % Abstract class for other types of currents.
    properties
    end
    methods
        function I = compute(self, t)
        end
    end
end